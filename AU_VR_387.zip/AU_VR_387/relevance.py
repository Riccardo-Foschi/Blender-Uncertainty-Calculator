import bpy
from bpy.types import Operator

# ------------------ Utilities ------------------

def assign_relevance_factor(factor):
    for obj in bpy.context.selected_objects:
        if obj.type == 'MESH':
            obj["Relevance"] = factor
    bpy.context.view_layer.update()

def reset_relevance_factor():
    for obj in bpy.context.selected_objects:
        if obj.type == 'MESH' and "Relevance" in obj:
            del obj["Relevance"]
    bpy.context.view_layer.update()

# ------------------ Operators ------------------

class AssignRelevance(Operator):
    bl_idname = "object.assign_relevance"
    bl_label = "Assign Relevance"
    bl_description = "Add a 'Relevance' property to the selected objects"

    def execute(self, context):
        factor = context.scene.relevance_factor
        assign_relevance_factor(factor)
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
        return {'FINISHED'}

class ResetRelevance(Operator):
    bl_idname = "object.reset_relevance"
    bl_label = "Reset Relevance"
    bl_description = "Remove the 'Relevance' property from selected objects"

    def execute(self, context):
        reset_relevance_factor()
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
        return {'FINISHED'}

# ------------------ Register ------------------

classes = (
    AssignRelevance,
    ResetRelevance,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.relevance_factor = bpy.props.FloatProperty(
        name="Relevance Factor",
        description="Weight of selected objects in AU_VR calculation",
        default=1.0, min=0.01, max=100.0
    )

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.relevance_factor
