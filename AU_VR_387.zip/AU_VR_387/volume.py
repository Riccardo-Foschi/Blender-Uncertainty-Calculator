import bpy
import bmesh
from bpy.types import Operator

# ------------------ Utilities ------------------

def calculate_volume(obj, self):
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    volume = bm.calc_volume(signed=True)
    bm.free()
    obj["Volume"] = volume
    self.report({'INFO'}, "Volume property created")
    bpy.context.view_layer.update()

def reset_volume(self):
    for obj in bpy.context.selected_objects:
        if obj.type == 'MESH' and "Volume" in obj:
            del obj["Volume"]
    self.report({'INFO'}, "Volume property removed")
    bpy.context.view_layer.update()

def apply_scale_selection(self):
    if bpy.context.selected_objects:
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        self.report({'INFO'}, "Selected objects scale applied")
    else:
        self.report({'ERROR'}, "Select something first!")

# ------------------ Operators ------------------

class CalculateVolume(Operator):
    bl_idname = "object.calculate_volume"
    bl_label = "Can take long for comeplex models"
    bl_description = "Calculate volume of selected meshes (must be closed, non-intersecting, applied scale)"

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        if bpy.context.selected_objects:
            for obj in bpy.context.selected_objects:
                if obj.type == 'MESH':
                    calculate_volume(obj, self)
        else:
            self.report({'ERROR'}, "Select something first!")
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
        return {'FINISHED'}

class ResetVolume(Operator):
    bl_idname = "object.reset_volume"
    bl_label = "Reset Volume"
    bl_description = "Remove volume property from selected meshes"

    def execute(self, context):
        if bpy.context.selected_objects:
            reset_volume(self)
        else:
            self.report({'ERROR'}, "Select something first!")
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
        return {'FINISHED'}

class ApplyScaleSelection(Operator):
    bl_idname = "object.apply_scale_selection"
    bl_label = "Apply Scale"
    bl_description = "Apply scale to selected objects (before calculating volume)"

    def execute(self, context):
        apply_scale_selection(self)
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
        return {'FINISHED'}

# ------------------ Register ------------------

classes = (
    CalculateVolume,
    ResetVolume,
    ApplyScaleSelection,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
