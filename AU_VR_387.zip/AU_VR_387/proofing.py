import bpy
import bmesh
import hashlib
import mathutils
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from bpy.types import Operator

# ------------------ Non-manifold detection ------------------

def find_non_manifold1():
    visible_objects = [obj for obj in bpy.data.objects if obj.visible_get()]
    for obj in bpy.context.scene.objects:
        if obj in visible_objects and obj.type == 'MESH':
            bpy.context.view_layer.objects.active = obj
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.context.tool_settings.mesh_select_mode = (False, True, False)
            bpy.ops.mesh.select_non_manifold()
            bpy.ops.object.mode_set(mode='OBJECT')

def find_non_manifold2():
    visible_objects = [obj for obj in bpy.data.objects if obj.visible_get()]
    non_manifold_objects = []
    bpy.ops.object.select_all(action='DESELECT')

    for obj in bpy.context.scene.objects:
        if obj in visible_objects and obj.type == 'MESH':
            bpy.context.view_layer.objects.active = obj
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.context.tool_settings.mesh_select_mode = (False, True, False)
            bpy.ops.mesh.select_non_manifold()
            selected_edges = len([e for e in obj.data.edges if e.select])
            if selected_edges > 1:
                non_manifold_objects.append(obj)
            bpy.ops.object.mode_set(mode='OBJECT')

    for obj in non_manifold_objects:
        obj.select_set(True)
    bpy.context.view_layer.update()
    non_manifold_objects.clear()

class FindNonManifold(Operator):
    bl_idname = "object.find_non_manifold"
    bl_label = "Can take long for complex models"
    bl_description = "Select all non-manifold meshes in the scene"

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

#The find non manifold function does not work for objects just imported
#in the scene, as a workaround I run the 'find_non_manifold1' funciton
#twice on all objects of the scene before running the actual find_non_manifold2
#function, it's a ugly workaround but it works.           
 
    def execute(self, context):
        find_non_manifold1()
        find_non_manifold2()
        return {'FINISHED'}
        

# ------------------ Delete zero area faces ------------------

class MESH_OT_delete_zero_area_faces(bpy.types.Operator):
    bl_idname = "mesh.delete_zero_area_faces"
    bl_label = "Erase Zero Area Faces"
    bl_description = "Erase Zero Area Faces before welding vertices"

    def execute(self, context):
        obj = context.active_object
        tol = context.scene.zero_area_tol
        
        if not selected_meshes:
            self.report({'ERROR'}, "Select something first!")
            return
        
        if obj and obj.type == 'MESH':
            # Stay in whatever mode user is, but ensure Edit Mode for BMesh
            prev_mode = obj.mode
            bpy.ops.object.mode_set(mode='EDIT')
            
            bm = bmesh.from_edit_mesh(obj.data)
            bm.faces.ensure_lookup_table()

            # Collect nearly-zero faces
            tiny_faces = [f for f in bm.faces if f.calc_area() < tol]

            if tiny_faces:
                bmesh.ops.delete(bm, geom=tiny_faces, context='FACES')
            
            bmesh.update_edit_mesh(obj.data)
            bpy.ops.object.mode_set(mode=prev_mode)

            self.report({'INFO'}, f"Deleted {len(tiny_faces)} faces with area < {tol}")
        else:
            self.report({'WARNING'}, "No mesh object selected")

        return {'FINISHED'}

# ------------------ Erase isolated non manifold geometry ------------------

def erase_non_manifold_and_isolated_faces(mesh):
    """Delete faces that (1) have both a non-manifold edge (>2 linked faces)
    and a naked edge (==1 linked face), plus delete isolated faces
    (all edges are naked). Writes back to mesh and returns count."""
    bm = bmesh.new()
    bm.from_mesh(mesh)

    bm.faces.ensure_lookup_table()
    bm.edges.ensure_lookup_table()

    to_delete = set()

    # Faces with both a non-manifold edge and a naked edge
    for f in bm.faces:
        counts = [len(e.link_faces) for e in f.edges]
        if any(c > 2 for c in counts) and any(c == 1 for c in counts):
            to_delete.add(f)

    # Isolated faces: every edge is naked (==1 linked face)
    for f in bm.faces:
        if all(len(e.link_faces) == 1 for e in f.edges):
            to_delete.add(f)

    deleted = 0
    if to_delete:
        deleted = len(to_delete)
        bmesh.ops.delete(bm, geom=list(to_delete), context='FACES')

    # --- Finalize step 1: write back so new loose geometry becomes detectable ---
    bm.to_mesh(mesh)
    mesh.update()
    bm.free()

    return deleted


def erase_loose_open_geometry(mesh):
    """Remove any remaining loose/open geometry created after face deletion:
    - delete edges with no linked faces (wire edges)
    - delete vertices with no linked edges (isolated verts)
    - delete isolated faces (all edges naked)
    Returns (faces_deleted, edges_deleted, verts_deleted)."""
    bm = bmesh.new()
    bm.from_mesh(mesh)

    bm.faces.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.verts.ensure_lookup_table()

    # Isolated faces
    iso_faces = [f for f in bm.faces if all(len(e.link_faces) == 1 for e in f.edges)]
    faces_deleted = 0
    if iso_faces:
        faces_deleted = len(iso_faces)
        bmesh.ops.delete(bm, geom=iso_faces, context='FACES')

    # Wire edges
    wire_edges = [e for e in bm.edges if len(e.link_faces) == 0]
    edges_deleted = 0
    if wire_edges:
        edges_deleted = len(wire_edges)
        bmesh.ops.delete(bm, geom=wire_edges, context='EDGES')

    # Refresh verts after edge deletion
    bm.verts.ensure_lookup_table()

    # Isolated verts
    iso_verts = [v for v in bm.verts if len(v.link_edges) == 0]
    verts_deleted = 0
    if iso_verts:
        verts_deleted = len(iso_verts)
        bmesh.ops.delete(bm, geom=iso_verts, context='VERTS')

    bm.to_mesh(mesh)
    mesh.update()
    bm.free()

    return faces_deleted, edges_deleted, verts_deleted


class MESH_OT_erase_nonmanifold_faces(bpy.types.Operator):
    bl_idname = "mesh.erase_nonmanifold_faces"
    bl_label = "Erase Non-Manifold Faces"
    bl_description = "Erase loose and non manifold geometry (isolated vert. edges and faces, and redundant faces)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_meshes = [obj for obj in context.selected_objects if obj.type == 'MESH']
        
        if not selected_meshes:
            self.report({'ERROR'}, "Select at least one mesh object.")
            return {'CANCELLED'}

        prev_mode = context.mode
        prev_active = context.view_layer.objects.active
        try:
            if prev_mode != 'OBJECT':
                context.view_layer.objects.active = selected_meshes[0]
                bpy.ops.object.mode_set(mode='OBJECT')
        except Exception:
            pass

        total_face_del = 0
        total_wire_del = 0
        total_vert_del = 0
        total_iso_face_del = 0

        for obj in selected_meshes:
            total_face_del += erase_non_manifold_and_isolated_faces(obj.data)
            f_del, e_del, v_del = erase_loose_open_geometry(obj.data)
            total_iso_face_del += f_del
            total_wire_del += e_del
            total_vert_del += v_del

        try:
            context.view_layer.objects.active = prev_active
            if prev_mode != 'OBJECT':
                bpy.ops.object.mode_set(mode=prev_mode)
        except Exception:
            pass

        self.report({'INFO'}, (
            f"Deleted {total_face_del} non-manifold/isolated faces, "
            f"{total_iso_face_del} isolated faces, {total_wire_del} wire edges, "
            f"and {total_vert_del} isolated verts across {len(selected_meshes)} mesh(es)."
        ))
        return {'FINISHED'}



# ------------------ Weld vertices ------------------

def weld_vertices_in_selected_meshes(self, context, merge_distance):
    selected_meshes = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']
    if not selected_meshes:
        self.report({'ERROR'}, "Select something first!")
        return
    for obj in selected_meshes:
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='EDIT')
        bm = bmesh.from_edit_mesh(obj.data)
        bmesh.ops.remove_doubles(bm, verts=bm.verts, dist = merge_distance)
        bmesh.update_edit_mesh(obj.data)
        bpy.ops.object.mode_set(mode='OBJECT')

class WeldVerticesSelection(Operator):
    bl_idname = "object.weld_vertices_in_selection"
    bl_label = "Reduce distance to avoid excessive vertex collapse"
    bl_description = "Weld vertices in selected objects. If this doesn't solve, please remodel the piece"

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        merge_distance = context.scene.weld_dist
        weld_vertices_in_selected_meshes(self, context, merge_distance)
        self.report({'INFO'}, "Vertices merged in all selected meshes")
        return {'FINISHED'}
        
        
# ------------------ Duplicates ------------------

# def mesh_data_hash(mesh):
    # m = hashlib.sha256()
    # for v in mesh.vertices:
        # m.update(v.co.to_tuple(5).__repr__().encode('utf-8'))
    # return m.hexdigest()

# def find_duplicate_meshes():
    # bpy.ops.object.select_all(action='DESELECT')
    # mesh_hash_map = {}
    # for obj in bpy.data.objects:
        # if obj.type != 'MESH':
            # continue
        # mesh_hash = mesh_data_hash(obj.data)
        # key = (
            # mesh_hash,
            # tuple(round(c, 5) for c in obj.location),
            # tuple(round(c, 5) for c in obj.rotation_euler),
            # tuple(round(c, 5) for c in obj.scale)
        # )
        # mesh_hash_map.setdefault(key, []).append(obj)
    # duplicates = []
    # for obj_list in mesh_hash_map.values():
        # if len(obj_list) > 1:
            # for dup_obj in obj_list[1:]:
                # dup_obj.select_set(True)
                # duplicates.append(dup_obj)
    # return duplicates

# class FindDups(Operator):
    # bl_idname = "object.find_duplicate_meshes"
    # bl_label = "Find Duplicate Meshes"
    # bl_description = "Select exact duplicate meshes"

    # def execute(self, context):
        # duplicates = find_duplicate_meshes()
        # if duplicates:
            # self.report({'INFO'}, f"{len(duplicates)} duplicate meshes selected")
        # else:
            # self.report({'INFO'}, "No duplicates found")
        # return {'FINISHED'}



# ------------------ Collisions and intersections ------------------

TEMP_COLL = "##TMP_BOOL##"

def ensure_collection_in_view_layers(coll):
    """Se la collezione è esclusa da tutti i view layer, la reincludiamo."""
    for layer in bpy.context.scene.view_layers:
        layer_coll = layer.layer_collection
        stack = [layer_coll]
        while stack:
            lc = stack.pop()
            if lc.collection == coll:
                if lc.exclude:
                    lc.exclude = False
                return  # trovato, basta
            stack.extend(lc.children)

def ensure_temp_collection(clear=False):
    if TEMP_COLL not in bpy.data.collections:
        coll = bpy.data.collections.new(TEMP_COLL)
        bpy.context.scene.collection.children.link(coll)
    coll = bpy.data.collections[TEMP_COLL]

    # assicura che la collezione sia inclusa nei view layer
    ensure_collection_in_view_layers(coll)

    if clear:
        for obj in list(coll.objects):
            bpy.data.objects.remove(obj, do_unlink=True)
    return coll

def cleanup_temp(obj, mesh):
    col = bpy.data.collections[TEMP_COLL]
    col.objects.unlink(obj)
    bpy.data.objects.remove(obj)
    bpy.data.meshes.remove(mesh)

def bounding_boxes_intersect(obj1, obj2, TOLERANCE):
    coords1 = [Vector(v) for v in obj1.bound_box]
    coords2 = [Vector(v) for v in obj2.bound_box]
    world1 = [obj1.matrix_world @ v for v in coords1]
    world2 = [obj2.matrix_world @ v for v in coords2]
    min1 = Vector((min(v.x for v in world1), min(v.y for v in world1), min(v.z for v in world1)))
    max1 = Vector((max(v.x for v in world1), max(v.y for v in world1), max(v.z for v in world1)))
    min2 = Vector((min(v.x for v in world2), min(v.y for v in world2), min(v.z for v in world2)))
    max2 = Vector((max(v.x for v in world2), max(v.y for v in world2), max(v.z for v in world2)))
    for i in range(3):
        if min(max1[i], max2[i]) - max(min1[i], min2[i]) <= TOLERANCE:
            return False
    return True

def mesh_bvh(obj):
    if obj.type != 'MESH':
        return None
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.transform(obj.matrix_world)
    tree = BVHTree.FromBMesh(bm)
    bm.free()
    return tree

def boolean_intersection_volume(obj_a, obj_b, keep_result=True, vol_tol=0):
    mesh_copy = obj_a.data.copy()
    obj_copy = bpy.data.objects.new("TMP_BOOL", mesh_copy)
    coll = ensure_temp_collection()
    coll.objects.link(obj_copy)
    obj_copy.matrix_world = obj_a.matrix_world

    mod = obj_copy.modifiers.new("TMP_BOOL_MOD", 'BOOLEAN')
    mod.operation = 'INTERSECT'
    mod.object = obj_b
    bpy.context.view_layer.objects.active = obj_copy
    bpy.ops.object.modifier_apply(modifier=mod.name)

    bm = bmesh.new()
    bm.from_mesh(obj_copy.data)
    bmesh.ops.triangulate(bm, faces=bm.faces)
    vol = abs(bm.calc_volume(signed=True))
    bm.free()

    if vol < vol_tol:
        cleanup_temp(obj_copy, mesh_copy)
        return 0

    if not keep_result:
        cleanup_temp(obj_copy, mesh_copy)

    return vol


def color_and_cleanup_tmp_bool():
    coll_name = "##TMP_BOOL##"
    if coll_name not in bpy.data.collections:
        return

    coll = bpy.data.collections[coll_name]
    
    for obj in bpy.data.collections[coll_name].objects:
        obj.show_in_front = True

    mat_name = "TMP_RED"
    if mat_name in bpy.data.materials:
        mat = bpy.data.materials[mat_name]
    else:
        mat = bpy.data.materials.new(mat_name)
        mat.diffuse_color = (1, 0, 0, 1)
        mat.use_nodes = False

    to_delete = []

    for obj in coll.objects:
        if obj.type == 'MESH':
            if len(obj.data.polygons) == 0:
                to_delete.append(obj)
                continue

            if len(obj.data.materials) == 0:
                obj.data.materials.append(mat)
            else:
                obj.data.materials[0] = mat

    for obj in to_delete:
        bpy.data.objects.remove(obj, do_unlink=True)



def find_true_intersections(objs, VOL_TOLERANCE):
    TOLERANCE = 1e-4
    bvhs = {o: mesh_bvh(o) for o in objs}
    sel = set()
    ensure_temp_collection(clear=True)
    for i, a in enumerate(objs):
        bvh_a = bvhs[a]
        if not bvh_a:
            continue
        for b in objs[i+1:]:
            bvh_b = bvhs[b]
            if not bvh_b:
                continue
            if not bounding_boxes_intersect(a, b, TOLERANCE = 1e-4):
                continue
            if not bvh_a.overlap(bvh_b):
                continue
            vol = boolean_intersection_volume(a, b, vol_tol=VOL_TOLERANCE)
            if vol > VOL_TOLERANCE:
                sel.add(a)
                sel.add(b)
    return sel

class OBJECT_OT_SelectIntersectingMeshes(Operator):
    bl_idname = "object.select_intersecting_meshes"
    bl_label = "Raise tolerance if false positives occurs"
    bl_description = "Select mesh objects that intersect each other"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        VOL_TOLERANCE = context.scene.vol_tol
        meshes = [o for o in context.selected_objects if o.type == 'MESH']
        if len(meshes) < 2:
            self.report({'ERROR'}, "Select at least two meshes first!")
            return {'CANCELLED'}
        inter = find_true_intersections(meshes, VOL_TOLERANCE=context.scene.vol_tol)
        bpy.ops.object.select_all(action='DESELECT')
        for o in inter:
            o.select_set(True)
        if inter:
            self.report({'INFO'}, f"{len(inter)} intersecting meshes selected")
        else:
            self.report({'INFO'}, "No intersections found")
            
        color_and_cleanup_tmp_bool()
        
        coll_name = "##TMP_BOOL##"
        if coll_name in bpy.data.collections:
            coll = bpy.data.collections[coll_name]
            coll.hide_render = True
            coll.hide_select = True
            coll.hide_viewport = False
        return {'FINISHED'}


class OBJECT_OT_ClearIntersectionPreview(Operator):
    bl_idname = "object.clear_intersection_preview"
    bl_label = "Clear Intersection Preview"
    bl_description = "Erase the ##TMP_BOOL## collection"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        coll_name = "##TMP_BOOL##"
        if coll_name in bpy.data.collections:
            coll = bpy.data.collections[coll_name]
            for obj in list(coll.objects):
                bpy.data.objects.remove(obj, do_unlink=True)
            bpy.data.collections.remove(coll)
            self.report({'INFO'}, "Cleared ##TMP_BOOL## collection")
        else:
            self.report({'INFO'}, "No ##TMP_BOOL## collection found")
        return {'FINISHED'}

# ------------------ Normals ------------------

def mesh_volume(obj):
    """Return the signed volume of a mesh. Negative means normals are inverted."""
    if obj.type != 'MESH':
        return None
    
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.transform(obj.matrix_world)  # apply object transforms
    
    volume = 0.0
    for f in bm.faces:
        p1 = f.verts[0].co
        for i in range(1, len(f.verts)-1):
            p2 = f.verts[i].co
            p3 = f.verts[i+1].co
            volume += (p1.cross(p2)).dot(p3)
    
    bm.free()
    return volume / 6.0  # signed volume

def has_inconsistent_orientation(obj):
    """Detect if the mesh has inconsistent face orientation (mixed winding)."""

    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.normal_update()

    faces = list(bm.faces)
    if not faces:
        bm.free()
        return False
    
    visited = set()
    stack = [faces[0]]
    visited.add(faces[0])

    while stack:
        f = stack.pop()
        for e in f.edges:
            linked_faces = [lf for lf in e.link_faces if lf != f]
            for lf in linked_faces:
                if lf not in visited:
                    verts_f = list(e.verts)

                    # sicurezza: controlla che entrambi i vertici appartengano davvero a lf
                    if verts_f[0] in lf.verts and verts_f[1] in lf.verts:
                        idx1 = f.verts[:].index(verts_f[0])
                        idx2 = f.verts[:].index(verts_f[1])
                        dir_f = (idx2 - idx1) % len(f.verts)

                        idx1_l = lf.verts[:].index(verts_f[0])
                        idx2_l = lf.verts[:].index(verts_f[1])
                        dir_l = (idx2_l - idx1_l) % len(lf.verts)

                        # Se la direzione coincide → winding inconsistente
                        if dir_f == dir_l:
                            bm.free()
                            return True

                    visited.add(lf)
                    stack.append(lf)

    bm.free()
    return False

def check_normals_and_select():
    bpy.ops.object.select_all(action='DESELECT')
    visible_objects = [obj for obj in bpy.data.objects if obj.visible_get()]
    
    for obj in bpy.context.scene.objects:
        if obj in visible_objects and obj.type == 'MESH':
            inverted = False
            inconsistent = False
            
            vol = mesh_volume(obj)
            if vol is not None and vol < 0:
                inverted = True
            
            if has_inconsistent_orientation(obj):
                inconsistent = True
            
            if inverted or inconsistent:
                obj.select_set(True)
                msg = []
                if inverted: msg.append("inverted normals")
                if inconsistent: msg.append("inconsistent winding")
                print(f"{obj.name} has {' and '.join(msg)}.")

class OBJECT_OT_CheckNormals(bpy.types.Operator):
    """Check for inverted or inconsistent normals"""
    bl_idname = "object.check_normals_custom"
    bl_label = "Can take long for complex models"
    bl_options = {'REGISTER', 'UNDO'}
    
    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        visible_objects = [obj for obj in bpy.data.objects if obj.visible_get()]
        for obj in bpy.context.scene.objects:
            if obj in visible_objects and obj.type == 'MESH':
                check_normals_and_select()
            return {'FINISHED'}

class OBJECT_OT_FixNormals(bpy.types.Operator):
    """Recalculate normals outside, clear custom split normals, clear sharp edges, then adds Auto Smooth modifier"""
    bl_idname = "object.fix_normals_custom"
    bl_label = "Fix Normals"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                bpy.context.view_layer.objects.active = obj

                # Recalculate normals outside
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.normals_make_consistent(inside=False)

                # Clear sharp edges
                bpy.ops.mesh.mark_sharp(clear=True)

                bpy.ops.object.mode_set(mode='OBJECT')

                # Use operator call to reset normals properly
                bpy.ops.mesh.customdata_custom_splitnormals_clear()

                # Shade Auto Smooth (with 30° angle)
                bpy.ops.object.shade_auto_smooth(angle=3.14159 / 6)
                
        return {'FINISHED'}



# ------------------ Register ------------------

classes = (
    FindNonManifold,
    WeldVerticesSelection,
    OBJECT_OT_SelectIntersectingMeshes,
    OBJECT_OT_ClearIntersectionPreview,
    OBJECT_OT_CheckNormals,
    OBJECT_OT_FixNormals,
    # FindDups,
    MESH_OT_delete_zero_area_faces,
    MESH_OT_erase_nonmanifold_faces
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.vol_tol = bpy.props.FloatProperty(name="Volume Tolerance", description="intersecting volumes smaller than this value will not be considered",default=1e-3, min=0.0000001, precision=4)        
    bpy.types.Scene.weld_dist = bpy.props.FloatProperty(name="Weld Distance", description="vertices closer than this distance will be welded",default=1e-3, min=0.0000001, precision=4)        
    bpy.types.Scene.zero_area_tol = bpy.props.FloatProperty(name="Zero Area Tolerance", description="Faces with area smaller than this will be deleted", default=1e-3, min=0.0000001,precision=4)
  

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.vol_tol
    del bpy.types.Scene.weld_dist    
    del bpy.types.Scene.zero_area_tol
