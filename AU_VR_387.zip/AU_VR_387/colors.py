import bpy
from bpy.props import FloatVectorProperty
from bpy.types import Operator, PropertyGroup

# ------------------ Utilities ------------------

def execute_reset_colors():
    bpy.ops.object.reset_colors_to_defaults()
    return None  # Stop the timer

def update_material(self, context):
    colors = [
        self.color1,
        self.color2,
        self.color3,
        self.color4,
        self.color5,
        self.color6,
        self.color7,
        self.color8
    ]
    for i, color in enumerate(colors, start=1):
        mat = bpy.data.materials.get(f"CustomMaterial{i}")
        if mat:
            mat.use_nodes = True
            bsdf = next((n for n in mat.node_tree.nodes if n.type == 'BSDF_PRINCIPLED'), None)
            if bsdf:
                bsdf.inputs[0].default_value = (color[0], color[1], color[2], 1)
                bsdf.inputs[2].default_value = 1.0

            # Update the material preview / viewport color
            mat.diffuse_color = (color[0], color[1], color[2], 1.0)

    # Force viewport refresh
    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            area.tag_redraw()
            
            
def assign_uncertainty_level(level):
    percentage_range = {
        1: (0, 14.285),
        2: (14.285, 28.571),
        3: (28.571, 42.857),
        4: (42.857, 57.143),
        5: (57.143, 71.428),
        6: (71.428, 85.714),
        7: (85.714, 100),
    }
    percentage_map = {i: (a+b)/2 for i, (a, b) in percentage_range.items()}
    for obj in bpy.context.selected_objects:
        if obj.type == 'MESH':
            obj["Uncertainty Level"] = level
            obj["Uncertainty Percentage"] = percentage_map[level]
    bpy.context.view_layer.update()
    return {'FINISHED'}

def reset_uncertainty_level():
    for obj in bpy.context.selected_objects:
        if obj.type == 'MESH':
            obj.pop("Uncertainty Level", None)
            obj.pop("Uncertainty Percentage", None)
    bpy.context.view_layer.update()

# ------------------ Operators ------------------

class ResetColorsToDefaults(Operator):
    bl_idname = "object.reset_colors_to_defaults"
    bl_label = "Reset colors to defaults"
    bl_description = "Reset the colours of the scale to the default colours (White, Blue, Cyan, Green, Yellow, Orange, Red, and Black)."

    def execute(self, context):
        color_map = {
            1: (1,1,1),
            2: (0,0,1),
            3: (0,1,1),
            4: (0,1,0),
            5: (1,1,0),
            6: (1,0.333,0),
            7: (1,0,0),
            8: (0,0,0)
        }
        for i, col in color_map.items():
            setattr(context.scene.my_tool, f"color{i}", col)
        self.report({'INFO'}, "Scale colors reset to defaults.")
        return {'FINISHED'}

# ---- Assign uncertainty operators (1..8) ----
def make_assign_op(idx, desc, reset=False):
    class AssignUncert(Operator):
        bl_idname = f"object.apply_material{idx}"
        bl_label = f"Apply Material {idx}"
        bl_description = desc
        def execute(self, context):
            color = getattr(context.scene.my_tool, f"color{idx}")
            mat = bpy.data.materials.get(f"CustomMaterial{idx}")
            if mat is None:
                mat = bpy.data.materials.new(name=f"CustomMaterial{idx}")
                mat.use_nodes = True
            bsdf = next((n for n in mat.node_tree.nodes if n.type == 'BSDF_PRINCIPLED'), None)
            if bsdf:
                bsdf.inputs[0].default_value = (*color, 1)
                bsdf.inputs[2].default_value = 1.0
            if context.selected_objects:
                for obj in context.selected_objects:
                    if obj.type == 'MESH':
                        if obj.data.materials:
                            obj.data.materials[0] = mat
                        else:
                            obj.data.materials.append(mat)
                        if reset:
                            reset_uncertainty_level()
                        else:
                            assign_uncertainty_level(idx)
                        mat.diffuse_color = (*color, 1)
            else:
                self.report({'ERROR'}, "Select something first!")
            return {'FINISHED'}
    return AssignUncert

# Descriptions of un certainty levels
AssignUncert1 = make_assign_op(1, "Reality-based data, good quality")
AssignUncert2 = make_assign_op(2, "Direct sources, reliable conjecture")
AssignUncert3 = make_assign_op(3, "Direct + Indirect sources, same authors")
AssignUncert4 = make_assign_op(4, "Direct + Indirect sources, different authors")
AssignUncert5 = make_assign_op(5, "Indirect sources, same authors, no direct sources")
AssignUncert6 = make_assign_op(6, "Indirect sources, different authors, no direct sources")
AssignUncert7 = make_assign_op(7, "Personal knowledge, missing sources")
AssignUncert8 = make_assign_op(8, "Abstention (remove uncertainty)", reset=True)

# ------------------ Properties ------------------

class ColorProperties(PropertyGroup):
    color1: FloatVectorProperty(name="Color1", subtype='COLOR', default=(1,1,1), min=0, max=1, update=update_material)
    color2: FloatVectorProperty(name="Color2", subtype='COLOR', default=(1,1,1), min=0, max=1, update=update_material)
    color3: FloatVectorProperty(name="Color3", subtype='COLOR', default=(1,1,1), min=0, max=1, update=update_material)
    color4: FloatVectorProperty(name="Color4", subtype='COLOR', default=(1,1,1), min=0, max=1, update=update_material)
    color5: FloatVectorProperty(name="Color5", subtype='COLOR', default=(1,1,1), min=0, max=1, update=update_material)
    color6: FloatVectorProperty(name="Color6", subtype='COLOR', default=(1,1,1), min=0, max=1, update=update_material)
    color7: FloatVectorProperty(name="Color7", subtype='COLOR', default=(1,1,1), min=0, max=1, update=update_material)
    color8: FloatVectorProperty(name="Color8", subtype='COLOR', default=(1,1,1), min=0, max=1, update=update_material)

# ------------------ Register ------------------

classes = (
    ResetColorsToDefaults,
    ColorProperties,
    AssignUncert1, AssignUncert2, AssignUncert3, AssignUncert4,
    AssignUncert5, AssignUncert6, AssignUncert7, AssignUncert8,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.my_tool = bpy.props.PointerProperty(type=ColorProperties)
    bpy.app.timers.register(execute_reset_colors, first_interval=0.1)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.my_tool
