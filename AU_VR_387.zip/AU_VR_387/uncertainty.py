import bpy
from bpy.types import Operator

# ------------------ Utilities ------------------

def calculate_average_uncertainty(self):
    total_volume = 0
    weighted_sum = 0

    for obj in bpy.data.objects:
        if obj.type == 'MESH':
            if "Uncertainty Level" in obj and "Volume" not in obj:
                self.report({'ERROR'}, f"Missing volume for {obj.name}")
                return 0
            elif "Uncertainty Level" in obj and "Volume" in obj:
                volume = obj["Volume"]
                uncertainty_percentage = obj["Uncertainty Percentage"]
                weighted_sum += volume * uncertainty_percentage
                total_volume += volume

    if total_volume == 0:
        return 0
    return weighted_sum / total_volume

def calculate_average_uncertainty_with_relevance(self):
    total_volume = 0
    weighted_sum = 0

    for obj in bpy.data.objects:
        if obj.type == 'MESH':
            if "Uncertainty Level" in obj and "Volume" not in obj:
                self.report({'ERROR'}, f"Missing volume for {obj.name}")
                return 0
            elif "Uncertainty Level" in obj and "Volume" in obj:
                volume = obj["Volume"]
                uncertainty_percentage = obj["Uncertainty Percentage"]
                relevance_factor = obj.get("Relevance", 1)
                weighted_sum += volume * uncertainty_percentage * relevance_factor
                total_volume += volume * relevance_factor

    if total_volume == 0:
        return 0
    return weighted_sum / total_volume

# ------------------ Operators ------------------

class CalculateAUV(Operator):
    bl_idname = "object.calculate_au_v"
    bl_label = "Calculate AU_V"
    bl_description = "Average uncertainty weighted on volume (AU_V)"

    def execute(self, context):
        au_v = calculate_average_uncertainty(self)
        context.scene.au_v_result = f"{au_v:.2f}%"
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
        return {'FINISHED'}

class CalculateAUVR(Operator):
    bl_idname = "object.calculate_au_vr"
    bl_label = "Calculate AU_VR"
    bl_description = "Average uncertainty weighted on volume & relevance (AU_VR)"

    def execute(self, context):
        au_vr = calculate_average_uncertainty_with_relevance(self)
        context.scene.au_vr_result = f"{au_vr:.2f}%"
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
        return {'FINISHED'}

# ------------------ Register ------------------

classes = (
    CalculateAUV,
    CalculateAUVR,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.au_v_result = bpy.props.StringProperty(
        name="AU_V Result",
        description="Result of AU_V calculation",
        default="%"
    )
    bpy.types.Scene.au_vr_result = bpy.props.StringProperty(
        name="AU_VR Result",
        description="Result of AU_VR calculation",
        default="%"
    )

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

    del bpy.types.Scene.au_v_result
    del bpy.types.Scene.au_vr_result
