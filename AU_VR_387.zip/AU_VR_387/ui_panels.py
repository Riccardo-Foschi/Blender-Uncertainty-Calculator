import bpy
from bpy.types import Panel


# ------------------ Import Panel ------------------

class Import_panel(Panel):
    bl_label = "Import OBJ"
    bl_idname = "IMPORT_PT_sidebar"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Uncertainty-7"
    bl_options = {'DEFAULT_CLOSED'}   # <<< pannello chiuso di default

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        
        box1 = layout.box()
        row = box1.row(align=True) 
        row.prop(scene, "import_invert_yz")
        row.prop(scene, "import_split_by_group")
        
        row = box1.row(align=True)
        row.prop(scene, "import_scale")   
        row = box1.row(align=True)
        row.operator("import_scene.multiple_obj_minimal", text="Import Multiple OBJ")        
  
# ------------------ Cleanup Panel ------------------
        
class Cleanup(Panel):
    bl_label = "Cleanup"
    bl_idname = "OBJECT_PT_cleanup_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Uncertainty-7"
    bl_options = {'DEFAULT_CLOSED'}   # <<< pannello chiuso di default

    def draw(self, context):
        layout = self.layout
        box1 = layout.box() 
      
        box1.operator("object.apply_scale_selection", text="Apply Scale", icon='FULLSCREEN_ENTER')
        box1.operator("wm.convert_and_collapse", text="Convert Empties to Collections", icon='COLLECTION_NEW')
        box1.operator("object.remove_materials", text="Clear Materials", icon='MATERIAL')
        box1.operator("object.clear_custom_properties", text="Clear Custom Properties", icon='PROPERTIES')  
 

# ------------------ Proofing Panel ------------------
 
class ModelProofing(Panel):
    bl_label = "Model Proofing"
    bl_idname = "OBJECT_PT_model_proofing"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Uncertainty-7"
    bl_options = {'DEFAULT_CLOSED'}   # <<< pannello chiuso di default

    def draw(self, context):
        layout = self.layout
        scene = context.scene

    ##---------------  non manifold box  ---------------##
        box1 = layout.box()
        box1.label(text="Non-Manifold and Open Objects")

        row = box1.row()
        row.operator("object.find_non_manifold", text="Find Non-Manifold Objects", icon='FACE_MAPS')
        
        # row = box1.row(align=True)
        # row.operator("mesh.delete_zero_area_faces", text="Erase Zero-Area Faces", icon="TRASH")
        # sub = row.row(align=True)
        # sub.scale_x = 0.65
        # sub.prop(scene, "zero_area_tol", text="Tol")
        
        # row = box1.row(align=True)  
        # row.operator("mesh.erase_nonmanifold_faces", text="Erase Isolated/Non-Manif. Geom", icon="TRASH")
        
        row = box1.row(align=True)
        row.operator("object.weld_vertices_in_selection", text="Weld Vertices", icon='AUTOMERGE_ON')
        sub = row.row(align=True)
        sub.scale_x = 0.65
        sub.prop(scene, "weld_dist", text="Dist")
        
        
    ##---------------  Normals box  ---------------##  
        box3 = layout.box()
        box3.label(text="Flipped Normals") 
        
        row = box3.row(align=True)           
        row.operator("object.check_normals_custom", text="Find Objects with Wrong Normals", icon='FACE_MAPS')
        row = box3.row(align=True) 
        row.operator("object.fix_normals_custom", text="Fix Normals", icon='NORMALS_FACE')
        
        
             
    ##---------------  Collision Box  ---------------##
        box2 = layout.box()
        box2.label(text="Colliding and Duplicate Objects")
        
        # row = box2.row(align=True)        
        # row.operator("object.find_duplicate_meshes", text="Find duplicate meshes", icon='MOD_OPACITY')   
        
        row = box2.row(align=True)    
        row.operator("object.select_intersecting_meshes", text="Test Collisions", icon='MOD_BOOLEAN')
        sub = row.row(align=True)
        sub.scale_x = 0.65 
        sub.prop(scene, "vol_tol", text="Tol")  

        row = box2.row(align=True)
        row.operator("object.clear_intersection_preview", text="Clear Intersection Preview", icon='X')
        

        
        
        
        



# ------------------ Assign Panel ------------------

class Assign(Panel):
    bl_label = "Assign"
    bl_idname = "OBJECT_PT_assign_uncertainty"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Uncertainty-7"

    def draw(self, context):
        layout = self.layout
        mytool = context.scene.my_tool

        box1 = layout.box()
        box1.label(text="Assign Uncertainty Level")

        row = box1.row()
        row.operator("object.reset_colors_to_defaults", text="Reset Scale Colours", icon='COLOR')

        for i in range(1, 9):
            percentage_range = (
        "(0-14%)",
        "(14-28%)",
        "(28-43%)",
        "(43-57%)",
        "(57-71%)",
        "(71-86%)",
        "(86-100%)",
    )
            
            row = box1.row(align=True)
            row.prop(mytool, f"color{i}", text="")
            sub = row.row()
            sub.scale_x = 2.0
            if i < 8:
                label = f"Uncertainty {i} {percentage_range[i-1]}"
            else:
                label = "Abstention"
            sub.operator(f"object.apply_material{i}", text=label)

        box2 = layout.box()
        box2.label(text="Assign Relevance Factor")
        row = box2.row(align=True)
        row.prop(context.scene, "relevance_factor", text="")
        sub = row.row()
        sub.scale_x = 1.5
        sub.operator("object.assign_relevance", text="Assign Relevance")
        row = box2.row()
        row.operator("object.reset_relevance", text="Remove Relevance")

# ------------------ Calculate Panel ------------------

class Calculate(Panel):
    bl_label = "Calculate"
    bl_idname = "OBJECT_PT_calculate_uncertainty"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Uncertainty-7"

    def draw(self, context):
        layout = self.layout
        box1 = layout.box()
        box1.label(text="Calculate Volume")
        
        row = box1.row()       
        row.operator("object.apply_scale_selection", text="Apply Scale", icon='FULLSCREEN_ENTER')
        row = box1.row() 
        row.operator("object.calculate_volume", text="Calculate Volume", icon='MESH_CUBE')
        row = box1.row()
        row.operator("object.reset_volume", text="Remove Volume", icon='CUBE')

        box2 = layout.box()
        box2.label(text="Calculate Average Uncertainty")
        row = box2.column()
        row.operator("object.calculate_au_v", text="Calculate AU_V")
        row.prop(context.scene, "au_v_result", text="AU_V")
        row = box2.column()
        row.operator("object.calculate_au_vr", text="Calculate AU_VR")
        row.prop(context.scene, "au_vr_result", text="AU_VR")

         

# ------------------ Select Panel ------------------
            
class Select(Panel):
    bl_label = "Select"
    bl_idname = "OBJECT_PT_select_uncertainty"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Uncertainty-7"
    bl_options = {'DEFAULT_CLOSED'}   # <<< pannello chiuso di default

    def draw(self, context):
        layout = self.layout

        box1 = layout.box()
        box1.label(text="Select by Uncertainty")
        row = box1.row(align=True)
        for i in range(1, 8):
            row.operator("object.select_by_uncertainty", text=str(i)).level = i

        box2 = layout.box()
        box2.label(text="Select by Relevance")
        row = box2.row(align=True)
        row.operator("object.select_by_relevance_small", text="Relev < 1")
        row.operator("object.select_by_relevance_1", text="Relev = 1")
        row.operator("object.select_by_relevance_big", text="Relev > 1")
        
        
# ------------------ Inspect Panel ------------------
 
class InspectObject(bpy.types.Panel):
    bl_label = "Inspect object"
    bl_idname = "INSPECT_OBJECT"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Uncertainty-7"

    def draw(self, context):
        layout = self.layout
        obj = context.object
        box1 = layout.box()

        if obj is None:
            box1.label(text="No obj selected")
            return

        box1.use_property_split = True
        box1.use_property_decorate = False

        col = box1.column(align=True)
        col.label(text=f"Object: {obj.name}")

        # Elenco custom props (escludo _RNA_UI che contiene solo metadati)
        keys = [k for k in obj.keys() if k != "_RNA_UI"]
        if not keys:
            col.label(text="(Custom Properties missing)")
            return

        for key in keys:
            row = col.row(align=True)
            try:
                row.prop(obj, f'["{key}"]', text=key)
            except Exception:
                row.label(text=f'{key}: <not supported>')

            ops = row.row(align=True)
            op = ops.operator("wm.properties_edit", text="", icon='PREFERENCES')
            op.data_path = "object"
            op.property_name = key

            op = ops.operator("wm.properties_remove", text="", icon='X')
            op.data_path = "object"
            op.property_name = key



# ------------------ Register ------------------

classes = (
    Import_panel,
    Cleanup,
    ModelProofing,
    Assign,
    Calculate,
    Select,
    InspectObject,    
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)     
        
        

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)