import bpy
import os
from bpy_extras.io_utils import ImportHelper
from bpy.types import Operator, Panel
from bpy.props import CollectionProperty, BoolProperty, FloatProperty


def collapse_all_outliners():
    wm = bpy.context.window_manager
    for win in wm.windows:
        screen = win.screen
        for area in screen.areas:
            if area.type != 'OUTLINER':
                continue
            region = next((r for r in area.regions if r.type == 'WINDOW'), None)
            if not region:
                continue
            space = area.spaces.active
            with bpy.context.temp_override(window=win, screen=screen, area=area, region=region, space_data=space):
                try:
                    for _ in range(32):
                        bpy.ops.outliner.show_one_level(open=False)
                except RuntimeError:
                    pass
            area.tag_redraw()
            
            

def import_obj_minimal(filepath, collection_name, invert_yz=False, scale=1.0, split_by_group=False):
    # Raw OBJ pools (global indices)
    verts_raw = []
    uvs_raw = []
    normals_raw = []

    # Face containers: we’ll always route faces through "groups" so we can remap cleanly
    groups = {}
    current_group = "Default"

    def ensure_group(gname):
        return groups.setdefault(gname, {
            "verts": [], "uvs": [], "normals": [],          # local compact arrays
            "vert_map": {}, "uv_map": {}, "normal_map": {}, # global->local maps
            "faces": [], "uv_faces": [], "normal_faces": [] # local-indexed faces
        })

    # If not splitting, we collect everything into a single synthetic group
    single_group_name = collection_name if collection_name else "OBJ"

    with open(filepath, 'r') as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('#'):
                continue

            if line.startswith('v '):  # vertex
                parts = line.split()
                x, y, z = map(float, parts[1:4])

                if invert_yz:
                    y, z = -z, y

                x *= scale
                y *= scale
                z *= scale
                verts_raw.append((x, y, z))

            elif line.startswith('vt '):  # uv
                parts = line.split()
                u, v = map(float, parts[1:3])
                uvs_raw.append((u, v))

            elif line.startswith('vn '):  # normal
                parts = line.split()
                nx, ny, nz = map(float, parts[1:4])
                if invert_yz:
                    ny, nz = -nz, ny
                normals_raw.append((nx, ny, nz))

            elif line.startswith('g '):  # group
                # Only relevant if split_by_group; otherwise we ignore and use a single bucket
                if split_by_group:
                    current_group = line.split(maxsplit=1)[1] if len(line.split()) > 1 else "Default"
                    ensure_group(current_group)

            elif line.startswith('f '):  # face (supports n-gons)
                parts = line.split()[1:]

                # pick target group container
                gname = current_group if split_by_group else single_group_name
                g = ensure_group(gname)

                face = []
                uv_face = []
                normal_face = []

                for p in parts:
                    # Supported formats: v, v/vt, v//vn, v/vt/vn
                    vals = p.split('/')
                    # vertex
                    v_idx = int(vals[0]) - 1
                    if v_idx not in g["vert_map"]:
                        g["vert_map"][v_idx] = len(g["verts"])
                        g["verts"].append(verts_raw[v_idx])
                    face.append(g["vert_map"][v_idx])

                    # uv
                    if len(vals) > 1 and vals[1] != '':
                        uv_idx = int(vals[1]) - 1
                        if 0 <= uv_idx < len(uvs_raw):
                            if uv_idx not in g["uv_map"]:
                                g["uv_map"][uv_idx] = len(g["uvs"])
                                g["uvs"].append(uvs_raw[uv_idx])
                            uv_face.append(g["uv_map"][uv_idx])
                        else:
                            uv_face.append(None)
                    else:
                        uv_face.append(None)

                    # normal
                    if len(vals) > 2 and vals[2] != '':
                        n_idx = int(vals[2]) - 1
                        if 0 <= n_idx < len(normals_raw):
                            if n_idx not in g["normal_map"]:
                                g["normal_map"][n_idx] = len(g["normals"])
                                g["normals"].append(normals_raw[n_idx])
                            normal_face.append(g["normal_map"][n_idx])
                        else:
                            normal_face.append(None)
                    else:
                        normal_face.append(None)

                g["faces"].append(face)
                g["uv_faces"].append(uv_face)
                g["normal_faces"].append(normal_face)

    # Use existing collection or create a new one
    if collection_name in bpy.data.collections:
        new_coll = bpy.data.collections[collection_name]
    else:
        new_coll = bpy.data.collections.new(collection_name)
        bpy.context.scene.collection.children.link(new_coll)

    def build_mesh(name, g):
        verts = g["verts"]
        faces = g["faces"]
        uvs = g["uvs"]
        uv_faces = g["uv_faces"]
        normals = g["normals"]
        normal_faces = g["normal_faces"]

        if not faces or not verts:
            print(f"⚠️ No geometry for {name}, skipping mesh")
            return

        mesh = bpy.data.meshes.new(name + "_mesh")
        mesh.from_pydata(verts, [], faces)
        mesh.update()

        # UVs
        has_any_uv = uvs and any(any(idx is not None for idx in poly_uv) for poly_uv in uv_faces)
        if has_any_uv:
            uv_layer = mesh.uv_layers.new(name="UVMap")
            for poly in mesh.polygons:
                poly_uvs = uv_faces[poly.index]
                for loop_pos, li in enumerate(poly.loop_indices):
                    uv_idx = poly_uvs[loop_pos % len(poly_uvs)]
                    if uv_idx is not None and 0 <= uv_idx < len(uvs):
                        uv_layer.data[li].uv = uvs[uv_idx]

        # Custom split normals
        has_any_normal = normals and any(any(idx is not None for idx in nf) for nf in normal_faces)
        if has_any_normal:
            clnors = []
            for poly in mesh.polygons:
                poly_n = normal_faces[poly.index]
                for loop_pos, li in enumerate(poly.loop_indices):
                    n_idx = poly_n[loop_pos % len(poly_n)]
                    if n_idx is not None and 0 <= n_idx < len(normals):
                        clnors.append(normals[n_idx])
                    else:
                        clnors.append(poly.normal)  # fallback
            try:
                mesh.normals_split_custom_set(clnors)
            except Exception as e:
                print(f"⚠️ Failed setting custom normals on {name}: {e}")

        obj = bpy.data.objects.new(name, mesh)
        new_coll.objects.link(obj)
        print(f"✅ Imported {obj.name}: {len(mesh.vertices)} verts, {len(mesh.polygons)} faces")

    # Build meshes
    if split_by_group:
        for gname, gdata in groups.items():
            build_mesh(f"{collection_name}_{gname}", gdata)
    else:
        gdata = groups.get(single_group_name)
        if gdata:
            build_mesh(collection_name, gdata)
        else:
            print("⚠️ Nothing to import (no faces parsed).")


class ImportMultipleOBJMinimal(Operator, ImportHelper):
    """Import multiple OBJ (minimal, UV + custom normals, proper per-group remap)"""
    bl_idname = "import_scene.multiple_obj_minimal"
    bl_label = "Import Multiple OBJ (minimal)"



    files: CollectionProperty(type=bpy.types.PropertyGroup)

    filter_glob: bpy.props.StringProperty(
        default="*.obj",
        options={'HIDDEN'},
        maxlen=255,
    )

## --------------------------------- modal logic to collapse all the outliner collection after import --------------------------------- ##
    _timer = None
    _step = 0
    
    def modal(self, context, event):
        if event.type == 'TIMER':
            if self._step == 0:
                collapse_all_outliners()
                self._step += 1
                return {'PASS_THROUGH'}
            else:
                context.window_manager.event_timer_remove(self._timer)
                return {'FINISHED'}
        return {'PASS_THROUGH'}


    def execute(self, context):
        directory = os.path.dirname(self.filepath)
        invert_yz = context.scene.import_invert_yz
        scale = context.scene.import_scale
        split_by_group = context.scene.import_split_by_group
        
        ## modal logic into the extecute def to collapse all the outliner collection after import
        for file_elem in self.files:
            filepath = os.path.join(directory, file_elem.name)
            name = os.path.splitext(file_elem.name)[0]
            import_obj_minimal(filepath, name, invert_yz, scale, split_by_group)         
        context.view_layer.update()
        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)          
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

def register():
    bpy.utils.register_class(ImportMultipleOBJMinimal)

    bpy.types.Scene.import_invert_yz = BoolProperty(name="Invert -Y/Z axes", description="Invert Y and Z axes signs when importing (-Y/Z)", default=False)

    bpy.types.Scene.import_scale = FloatProperty(name="Scale", description="Scaling factor applied to all vertices", default=0.01, min=0.0001)

    bpy.types.Scene.import_split_by_group = BoolProperty(name="Split Group", description="Import each OBJ group as a separate object", default=True )


def unregister():
    del bpy.types.Scene.import_invert_yz
    del bpy.types.Scene.import_scale
    del bpy.types.Scene.import_split_by_group

    bpy.utils.unregister_class(ImportMultipleOBJMinimal)


if __name__ == "__main__":
    register()
