import bpy
from bpy.types import Operator




# ------------------ Convert Empties to Collections (useful when importing GLBs from Rhino)------------------

def empties_to_collections():
    def _ensure_link(parent_coll, coll):
        if not any(c is coll for c in parent_coll.children):
            parent_coll.children.link(coll)
        # Unlink from other parents to keep the hierarchy clean
        for maybe_parent in bpy.data.collections:
            if any(c is coll for c in maybe_parent.children) and maybe_parent is not parent_coll:
                maybe_parent.children.unlink(coll)
        # Also unlink from Scene Collection if needed
        scene_coll = bpy.context.scene.collection
        if any(c is coll for c in scene_coll.children) and parent_coll is not scene_coll:
            scene_coll.children.unlink(coll)

    def _convert_empty(empty, parent_coll):
        # Reuse existing collection by name, or create it
        coll = bpy.data.collections.get(empty.name) or bpy.data.collections.new(empty.name)
        _ensure_link(parent_coll, coll)

        # Process children
        for child in list(empty.children):
            mw = child.matrix_world.copy()  # keep world transform
            child.parent = None
            child.matrix_world = mw
            if child.type == 'EMPTY':
                _convert_empty(child, coll)
            else:
                if not any(o is child for o in coll.objects):
                    coll.objects.link(child)
                # Make sure the object only lives in this collection
                for c in list(child.users_collection):
                    if c is not coll:
                        c.objects.unlink(child)

        # Remove the converted empty
        bpy.data.objects.remove(empty, do_unlink=True)

    # Start from root empties and recurse down
    roots = [o for o in bpy.context.scene.objects if o.type == 'EMPTY' and o.parent is None]
    for root in roots:
        _convert_empty(root, bpy.context.scene.collection)


def collapse_all_outliners():
    wm = bpy.context.window_manager
    for win in wm.windows:
        screen = win.screen
        for area in screen.areas:
            if area.type != 'OUTLINER':
                continue
            region = next((r for r in area.regions if r.type == 'WINDOW'), None)
            if not region:
                continue
            space = area.spaces.active
            with bpy.context.temp_override(window=win, screen=screen, area=area, region=region, space_data=space):
                try:
                    for _ in range(32):
                        bpy.ops.outliner.show_one_level(open=False)
                except RuntimeError:
                    pass
            area.tag_redraw()

class ConvertAndCollapseOperator(bpy.types.Operator):
    bl_idname = "wm.convert_and_collapse"
    bl_label = "Convert Empties and Collapse Outliner"
    bl_description = "Convert all the first level empties into collections, useful to reorganize an imported scene (e.g. GLB from Rhinoceros)"

    _timer = None
    _step = 0

    def modal(self, context, event):
        if event.type == 'TIMER':
            if self._step == 0:
                collapse_all_outliners()
                self._step += 1
                return {'PASS_THROUGH'}
            else:
                context.window_manager.event_timer_remove(self._timer)
                return {'FINISHED'}
        return {'PASS_THROUGH'}

    def execute(self, context):
        empties_to_collections()
        
        context.view_layer.update()
        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}






# ------------------ Clear custom properties ------------------

def clear_custom_properties_for_selected_objects(self, context):
    selected_objects = bpy.context.selected_objects
    if not selected_objects:
        self.report({'ERROR'}, "Select something first!")
        return {"CANCELLED"}

    for obj in selected_objects:
        if hasattr(obj, "keys"):
            for prop in list(obj.keys()):
                if prop not in {"_RNA_UI"}:
                    del obj[prop]
        bpy.context.view_layer.update()

    for area in bpy.context.window.screen.areas:
        if area.type == 'PROPERTIES':
            area.tag_redraw()

    return {"FINISHED"}
    
    
class ClearCustomProperties(Operator):
    bl_idname = "object.clear_custom_properties"
    bl_label = "Clear Custom Properties from selection"
    bl_description = "Remove all custom properties from selected objects"

    def execute(self, context):
        clear_custom_properties_for_selected_objects(self, context)
        
        self.report({'INFO'}, "Custom properties removed successfully!")
        bpy.context.area.tag_redraw()
        return {'FINISHED'}






# ------------------ Remove materials ------------------

class RemoveMaterials(Operator):
    bl_idname = "object.remove_materials"
    bl_label = "Remove Materials from selection"
    bl_description = "Remove all materials from selected objects"

    def execute(self, context):
        selected_objects = bpy.context.selected_objects
        if not selected_objects:
            self.report({'ERROR'}, "Select something first!")
            return {"CANCELLED"}

        for obj in selected_objects:
            if obj.type == 'MESH':
                obj.data.materials.clear()

        self.report({'INFO'}, "Materials removed successfully!")
        return {'FINISHED'}
        
        
        




# ------------------ Register ------------------

classes = (
    RemoveMaterials,
    ClearCustomProperties,
    ConvertAndCollapseOperator
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
