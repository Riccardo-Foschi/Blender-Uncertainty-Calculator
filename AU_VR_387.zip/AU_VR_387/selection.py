import bpy
from bpy.types import Operator

# ------------------ Operators ------------------

class SelectByUncertainty(Operator):
    bl_idname = "object.select_by_uncertainty"
    bl_label = "Select by Uncertainty"
    bl_description = "Select objects with a given uncertainty level"

    level: bpy.props.IntProperty()

    def execute(self, context):
        bpy.ops.object.select_all(action='DESELECT')
        for obj in bpy.data.objects:
            if obj.type == 'MESH' and  "Uncertainty Level" in obj and obj["Uncertainty Level"] == self.level:
                obj.select_set(True)
        return {'FINISHED'}

class SelectBigRelevance(Operator):
    bl_idname = "object.select_by_relevance_big"
    bl_label = "Select Relevance > 1"
    bl_description = "Select objects with Relevance > 1"

    def execute(self, context):
        bpy.ops.object.select_all(action='DESELECT')
        for obj in bpy.data.objects:
            if obj.type == 'MESH' and "Relevance" in obj and obj["Relevance"] > 1:
                obj.select_set(True)
        return {'FINISHED'}

class SelectSmallRelevance(Operator):
    bl_idname = "object.select_by_relevance_small"
    bl_label = "Select Relevance < 1"
    bl_description = "Select objects with Relevance < 1"

    def execute(self, context):
        bpy.ops.object.select_all(action='DESELECT')
        for obj in bpy.data.objects:
            if obj.type == 'MESH' and "Relevance" in obj and obj["Relevance"] < 1:
                obj.select_set(True)
        return {'FINISHED'}

class SelectRelevance1(Operator):
    bl_idname = "object.select_by_relevance_1"
    bl_label = "Select Relevance = 1 (or none)"
    bl_description = "Select objects with Relevance = 1 or without Relevance"

    def execute(self, context):
        bpy.ops.object.select_all(action='DESELECT')
        for obj in bpy.data.objects:
            if (obj.type == 'MESH' and "Relevance" in obj and obj["Relevance"] == 1) or (obj.type == 'MESH' and "Relevance" not in obj):
                obj.select_set(True)
        return {'FINISHED'}

# ------------------ Register ------------------

classes = (
    SelectByUncertainty,
    SelectBigRelevance,
    SelectSmallRelevance,
    SelectRelevance1,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
