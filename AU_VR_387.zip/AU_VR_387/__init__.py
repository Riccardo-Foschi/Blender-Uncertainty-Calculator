bl_info = {
    "name": "Uncertainty quantification",
    "type": "extension",    
    "blender": (2, 80, 0),
    "Location": "Side panel (N shortcut) > Uncertainty",
    "category": "Model Analysis",
    "author": "Riccardo Foschi",
    "description": " Provides tools to import, validate and assess uncertainty of 3D architectural models. Documentation on GitHub",
    "version": (3, 8, 7),
}

# Import internal modules
from . import colors, relevance, volume, uncertainty, selection, cleanup, proofing, ui_panels, import_panel


modules = (
    colors,
    relevance,
    volume,
    uncertainty,
    selection,
    cleanup,
    proofing,
    ui_panels,
    import_panel,
)

def register():
    for m in modules:
        m.register()

def unregister():
    for m in reversed(modules):
        m.unregister()

if __name__ == "__main__":
    register()
